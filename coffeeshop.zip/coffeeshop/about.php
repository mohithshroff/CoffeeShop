<!DOCTYPE html>
<html>

<head>
	<title>COFFEESHOP MANAGEMENT</title>
	<meta name="viewport" content="width=device-width,initial-scale=1">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.1/css/all.min.css" />
	<link rel="stylesheet" href="css/fonts.css">
	<link rel="stylesheet" href="font.css">
	<link rel="stylesheet" href="about.css">
	<style>
		#style1{
			font-weight: bold;
			font-size: 25%;
		}
	</style>
</head>
<body>

<div class="nav">
			<div class="image-sec">
				<img src="admin/images/coffeelogo.png" class="img-prop1">
			</div>
			<div class="menu-sec">
				<ul class="ul-menu">
					<li><a href="index.php" class="navlink">Home</a></li>
					<li id="login"><a href="login.php" class="navlink">Login</a></li>
					<li id="admin"><a href="admin/admin_index.php" class="navlink">Admin</a></li>
				</ul>
			</div>
		</div>
		 <div class="about2" >
			     <p style="font-size:50px; font-family:Vladimir Script; margin-top:20px; margin-left:90px; " > <b>Welcome </b></p>
				 <p   style="font-size:20px; font-family:Vladimir Script; margin-top:-50px; margin-left:50px; " > TO OUR COFFEE HOUSE </p>
				 
				 <img src="admin/images/login4.jpg" style="height:280px; width:300px; border:9px solid  #D1C6B2; margin-top:30px;margin-left:30px;" />
			</div>
			
			<div  class="about3">
			<p style="font-size:50px; font-family:Times New Roman; margin-top:20px; margin-left:90px; " > <b>About cafe</b></p>
			<p style="font-size:28px; margin-top:-28px;">Coffee House is India's favourite coffee shop for the young and the young at heart. We strive to provide the best experience to our guests. To put it plainly, we brought in the concept of cafes to India.The young and the young at heart immediately took to the place. A smart, simple space that they could call their own for a while… sit down, talk and listen to conversations, hold short meetings or even have a lot of good fun…all over steaming cups of coffee. Coffe House today is totally in tune with its target audience. It’s a strong relationship the brand shares. </p>		
			</div>

</body>
</html>		